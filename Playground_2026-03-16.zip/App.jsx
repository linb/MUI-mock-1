import React from 'react';
import { 
  Box, 
  Button, 
  Card, 
  CardContent, 
  CardMedia, 
  Chip, 
  Dialog, 
  DialogActions, 
  DialogContent, 
  DialogContentText, 
  DialogTitle, 
  Fab, 
  Grid, 
  IconButton, 
  InputBase, 
  ListItem, 
  ListItemAvatar, 
  ListItemText, 
  MenuItem, 
  Menu, 
  Paper, 
  Skeleton, 
  Slider, 
  Snackbar, 
  Stack, 
  Tab, 
  Tabs, 
  TextField, 
  ToggleButton, 
  ToggleButtonGroup, 
  Typography 
} from '@mui/material';
import { 
  Add, 
  Archive, 
  Delete, 
  Favorite, 
  Share, 
  Star 
} from '@mui/icons-material';

export default function App() {
  const [open, setOpen] = React.useState(false);
  const [value, setValue] = React.useState(0);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Card sx={{ maxWidth: 345 }}>
            <CardMedia
              component="img"
              height="140"
              image="https://source.unsplash.com/random"
              alt="green iguana"
            />
            <CardContent>
              <Typography gutterBottom variant="h5" component="div">
                Lizard
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Lizards are a group of reptiles that belong to the order Squamata,
                which also includes snakes. They are found all over the world, in almost
                every type of habitat.
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Paper elevation={3} sx={{ padding: 2 }}>
            <Typography variant="h6">Paper</Typography>
            <Typography variant="body2" color="text.secondary">
              This is a paper component.
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <Button variant="contained">Contained</Button>
            <Button variant="outlined">Outlined</Button>
            <Button variant="text">Text</Button>
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <ToggleButton value="check" selected>
              <Archive />
            </ToggleButton>
            <ToggleButton value="check" selected>
              <Delete />
            </ToggleButton>
            <ToggleButton value="check" selected>
              <Favorite />
            </ToggleButton>
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <Chip label="Chip" />
            <Chip label="Chip" variant="outlined" />
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <Fab color="primary" aria-label="add">
              <Add />
            </Fab>
            <Fab color="secondary" aria-label="edit">
              <Share />
            </Fab>
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <IconButton aria-label="favorite" color="primary">
              <Favorite />
            </IconButton>
            <IconButton aria-label="star" color="secondary">
              <Star />
            </IconButton>
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <InputBase
              placeholder="Search…"
              inputProps={{ 'aria-label': 'search' }}
            />
            <TextField id="standard-basic" label="Standard" variant="standard" />
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <ListItem>
              <ListItemAvatar>
                <Archive />
              </ListItemAvatar>
              <ListItemText primary="Single-line item" secondary="Secondary text" />
            </ListItem>
            <ListItem>
              <ListItemAvatar>
                <Delete />
              </ListItemAvatar>
              <ListItemText primary="Single-line item" secondary="Secondary text" />
            </ListItem>
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <Menu
              id="demo-positioned-menu"
              aria-labelledby="demo-positioned-button"
              open={open}
              onClose={handleClose}
              anchorOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'left',
              }}
            >
              <MenuItem onClick={handleClose}>Profile</MenuItem>
              <MenuItem onClick={handleClose}>My account</MenuItem>
              <MenuItem onClick={handleClose}>Logout</MenuItem>
            </Menu>
            <Button
              id="demo-positioned-button"
              aria-controls={open ? 'demo-positioned-menu' : undefined}
              aria-haspopup="true"
              aria-expanded={open ? 'true' : undefined}
              onClick={handleClickOpen}
            >
              Open menu
            </Button>
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <Dialog
              open={open}
              onClose={handleClose}
              aria-labelledby="alert-dialog-title"
              aria-describedby="alert-dialog-description"
            >
              <DialogTitle id="alert-dialog-title">
                {"Use Google's location service?"}
              </DialogTitle>
              <DialogContent>
                <DialogContentText id="alert-dialog-description">
                  Let Google help apps determine location. This means sending anonymous location data to
                  Google, even when no apps are running.
                </DialogContentText>
              </DialogContent>
              <DialogActions>
                <Button onClick={handleClose}>Disagree</Button>
                <Button onClick={handleClose} autoFocus>
                  Agree
                </Button>
              </DialogActions>
            </Dialog>
            <Button variant="contained" onClick={handleClickOpen}>
              Open dialog
            </Button>
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <ToggleButtonGroup
              value={value}
              exclusive
              onChange={handleChange}
            >
              <ToggleButton value="one">One</ToggleButton>
              <ToggleButton value="two">Two</ToggleButton>
              <ToggleButton value="three">Three</ToggleButton>
            </ToggleButtonGroup>
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <Slider
              aria-label="Temperature"
              defaultValue={30}
              valueLabelDisplay="auto"
              step={10}
              marks
              min={10}
              max={110}
            />
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <Skeleton variant="rectangular" width={210} height={118} />
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <Snackbar
              open={open}
              autoHideDuration={6000}
              onClose={handleClose}
              message="Note archived"
            />
            <Button variant="contained" onClick={handleClickOpen}>
              Open snackbar
            </Button>
          </Stack>
        </Grid>
        <Grid item xs={12} sm={6} md={4} lg={3} xl={2}>
          <Stack spacing={2}>
            <Tabs
              value={value}
              onChange={handleChange}
              aria-label="basic tabs example"
            >
              <Tab label="Item One" />
              <Tab label="Item Two" />
              <Tab label="Item Three" />
            </Tabs>
          </Stack>
        </Grid>
      </Grid>
    </Box>
  );
}